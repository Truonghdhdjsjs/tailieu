<footer id="footer"><!--Footer-->
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-3">
						<div class="single-widget">
							<h2>Chăm sóc khách hàng</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Liên Hệ Trực Tuyến</a></li>
								<li><a href="#">Trung Tâm Trợ Giúp</a></li>
								<li><a href="#">Thanh Toán</a></li>
								<li><a href="#">Vận Chuyển</a></li>
								<li><a href="#">Trả Hàng Và Hoàn Tiền</a></li>
								<li><a href="#">Chính Sách Bảo Hành</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="single-widget">
							<h2>Về Chúng Tôi</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Giới Thiệu</a></li>
								<li><a href="#">Điều Khoản Sử Dụng</a></li>
								<li><a href="#">Chính Sách Bảo Mật</a></li>
								<li><a href="#">Tuyển Dụng</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="single-widget">
							<h2>Thanh Toán</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Vietcombank</a></li>
								<li><a href="#">Techcombank</a></li>
								<li><a href="#">Agribank</a></li>
								<li><a href="#">Vietinbank</a></li>
								<li><a href="#">MOMO</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="single-widget">
							<h2>Theo Dõi Chúng Tôi</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">facebook</a></li>
								<li><a href="#">instagram</a></li>
								<li><a href="#">youtobe</a></li>
								<li><a href="#">zalo</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Nhóm 4 - Website Bán Quần Áo</p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
    <script src="public/client/js/jquery.js"></script>
	<script src="public/client/js/bootstrap.min.js"></script>
	<script src="public/client/js/jquery.scrollUp.min.js"></script>
	<script src="public/client/js/price-range.js"></script>
    <script src="public/client/js/jquery.prettyPhoto.js"></script>
    <script src="public/client/js/main.js"></script>