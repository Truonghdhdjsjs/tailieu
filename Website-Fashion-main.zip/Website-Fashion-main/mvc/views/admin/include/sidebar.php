
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3></h3>
                <ul class="nav side-menu">
                  <li><a href="<?=base?>admin/home"><i class="fa fa-dashboard"></i> Bản Điều Khiển</a>
                  </li>
                  <li><a href="<?=base?>admin/useraccount"><i class="fa fa-users"></i>Quản Lí Khách Hàng</a></li>
                  <li><a href="<?=base?>admin/order"><i class="fa fa-shopping-cart"></i>Quản Lí Đơn Hàng</a></li>
                  <li><a href="<?=base."admin/showcategory"?>"><i class="fa fa-list"></i>Quản Lí Danh Mục</a></li>
                  <li><a href="<?=base."admin/showproduct"?>"><i class="fa fa-archive"></i>Quản Lí Sản Phẩm</a></li>
                  <!-- <li><a href="<?=base."admin/showslider"?>"><i class="fa fa-slideshare"></i>Quản Lí Slider</a></li>
                  <li><a href="<?=base."admin/comment"?>"><i class="fa fa-slideshare"></i>Quản Lí Comment</a></li>
                  <li><a href="admin/ChangePass"><i class="fa fa-cog"></i>Đổi Mật Khẩu</a></li>
                  <li><a onclick="logout('<?=base.'logout/admin'?>')" class="dropdown-item" href="javascript:void(0)"><i class="fa fa-sign-out pull-left"></i>Đăng Xuất</a></li> -->
                </ul>
              </div>
            </div>