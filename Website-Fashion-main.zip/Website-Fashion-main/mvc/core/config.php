<?php
    define("base","http://localhost/web_quan_ao_edit/");
    // đường dẫn đến thư mục chứa hình ảnh sản phẩm
    define("urlFileProduct","public/images/img_product/");
?>