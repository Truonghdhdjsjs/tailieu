<?php
    class contact extends controller{
        //Trang Liên Hệ
        function contact()
        {
            $data =[];
            $this->ViewClinet("contact",$data);  
        }
    }
?>