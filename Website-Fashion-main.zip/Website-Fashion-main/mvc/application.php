<?php
    require_once "./mvc/core/main.php";
    require_once "./mvc/core/controller.php";
    require_once "./mvc/core/database.php";
    require_once "./mvc/core/config.php";
    require_once "./mvc/core/notification.php";
    require_once "mvc/core/randomcookie.php";
    require_once "./mvc/core/checkunicode.php";
    require_once "./mvc/core/uploadfile.php";
?>