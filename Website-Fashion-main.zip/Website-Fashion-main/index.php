<?php
session_start();
require_once "./mvc/application.php";
$mai = new main();
?>